

function searchgamemanager(message){
    
}